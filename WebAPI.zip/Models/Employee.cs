﻿namespace BalochistanCultureWebAPI.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int phnumber { get; set; }
    }
}
