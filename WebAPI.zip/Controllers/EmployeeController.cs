﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BalochistanCultureWebAPI.Models;
using BalochistanCultureWebAPI.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Azure.Core;
using Azure;
using Microsoft.AspNetCore.Hosting;
using System.Xml;


namespace BalochistanCultureWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        

        [HttpGet("GetEmployee/{ID}/{name}/{phnum}")]
        public string GetEmployee(int ID, string name, int phnum)
        {
            return "Enter your id" + ID + "Enter your name" + name + "Enter your phonenumber" + phnum;
        }
        [HttpPost("SaveEmployee/{ID}/{nm}/{phnm}")]

       public string SaveEmployee(Employee employee)
        {
              return "Enter your id" + employee.Id + "Enter your name" + employee.Name + "Enter your Phonenumber" + employee.phnumber; 
        }
       
    }
    
    }

